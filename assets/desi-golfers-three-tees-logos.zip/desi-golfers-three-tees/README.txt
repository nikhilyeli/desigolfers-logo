DesiGolfers · Three Tees logo files
Logo & brand identity by Nikhil Yeli (India) · Instagram @nikki.nikhil.1811

symbol/   symbol only, 5 colourways, transparent
lockup/   horizontal lockups, 6 text versions x 5 colourways
vertical/ vertical lockups, 6 text versions x 5 colourways
stacked/  English over Telugu
social/   avatars, YouTube banner, Facebook cover
pattern/  repeat patterns

SVGs with type load fonts from Google Fonts; outline text before print.

Soil and White share the same chalk-coloured logo, so transparent Soil files are not duplicated: use the white-transparent files (symbol/white.*) on soil backgrounds.
